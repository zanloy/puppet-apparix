## Overview

Installs apparix on a node. This was developed on RedHat based systems but should
work on any linux system.

## Usage

There are no configurable options to this module so you can use a basic include style
declaration.
